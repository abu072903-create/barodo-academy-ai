const chat = document.getElementById("chat");
const form = document.getElementById("chatForm");
const input = document.getElementById("question");
const sendBtn = document.getElementById("sendBtn");
const level = document.getElementById("level");
const subject = document.getElementById("subject");
const language = document.getElementById("language");

document.getElementById("year").textContent = new Date().getFullYear();

function addMessage(kind, title, text) {
  const box = document.createElement("div");
  box.className = `message ${kind}`;
  const heading = document.createElement("b");
  heading.textContent = title;
  const paragraph = document.createElement("p");
  paragraph.textContent = text;
  box.append(heading, paragraph);
  chat.appendChild(box);
  chat.scrollTop = chat.scrollHeight;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = input.value.trim();
  if (!message) return;

  addMessage("student", "You", message);
  input.value = "";
  sendBtn.disabled = true;
  sendBtn.textContent = "Thinking...";

  try {
    const response = await fetch("/api/tutor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message,
        level: level.value,
        subject: subject.value,
        language: language.value
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not get an answer.");
    addMessage("teacher", "BARODO AI Teacher", data.answer);
  } catch (error) {
    addMessage("teacher", "BARODO AI Teacher", error.message);
  } finally {
    sendBtn.disabled = false;
    sendBtn.innerHTML = 'Send <span>➤</span>';
    input.focus();
  }
});

document.querySelectorAll("[data-subject]").forEach((button) => {
  button.addEventListener("click", () => {
    subject.value = button.dataset.subject;
    document.getElementById("question").focus();
  });
});

let score = 0;
document.querySelectorAll("[data-answer]").forEach((button) => {
  button.addEventListener("click", () => {
    const feedback = document.getElementById("quizFeedback");
    if (button.dataset.answer === "correct") {
      score += 1;
      document.getElementById("score").textContent = score;
      feedback.textContent = "Correct! Roots absorb water from the soil. Da kyau!";
    } else {
      feedback.textContent = "Not quite. Try again: which plant part is usually underground?";
    }
  });
});
