import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

const tutorLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 12,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many messages. Please wait a minute and try again." }
});

app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    app: "BARODO ACADEMY AI",
    aiConfigured: Boolean(process.env.GROQ_API_KEY)
  });
});

app.post("/api/tutor", tutorLimiter, async (req, res) => {
  try {
    const { message, level = "SS 1", subject = "General", language = "Bilingual" } = req.body || {};

    if (typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ error: "Please enter a question first." });
    }
    if (message.length > 4000) {
      return res.status(400).json({ error: "Your question is too long. Please use fewer than 4,000 characters." });
    }
    if (!process.env.GROQ_API_KEY) {
      return res.status(503).json({
        error: "The AI teacher is not connected yet. Add GROQ_API_KEY in your hosting environment settings."
      });
    }

    const model = process.env.GROQ_MODEL || "llama-3.3-70b-versatile";
    const systemPrompt = `You are BARODO ACADEMY AI, a patient and encouraging educational tutor.
Teach the learner at ${level} level. Subject: ${subject}. Preferred language: ${language}.
Explain clearly in small steps. If Bilingual is selected, explain in simple English and Hausa.
Use examples and check understanding. Do not pretend to know a syllabus detail if uncertain.
For schoolwork, teach the method rather than simply doing all the work. Keep answers age-appropriate.`;

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.GROQ_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: message.trim() }
        ],
        temperature: 0.6,
        max_tokens: 900
      })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error("AI provider error:", data);
      return res.status(502).json({
        error: data?.error?.message || "The AI service could not answer right now. Please try again."
      });
    }

    const answer = data?.choices?.[0]?.message?.content;
    if (!answer) {
      return res.status(502).json({ error: "The AI service returned an empty answer. Please try again." });
    }
    res.json({ answer });
  } catch (error) {
    console.error("Tutor route error:", error);
    res.status(500).json({ error: "Something went wrong. Please try again." });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`BARODO ACADEMY AI running on port ${PORT}`);
});
