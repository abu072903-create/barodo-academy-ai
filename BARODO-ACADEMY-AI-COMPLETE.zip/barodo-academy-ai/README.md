# BARODO ACADEMY AI

A beginner-friendly educational platform starter with a multilingual AI tutor.

## Included
- Responsive learning dashboard
- School level selector: Primary 1–6, JSS 1–3, SS 1–3, University
- Subject selector
- AI tutor with English, Hausa, or bilingual preference
- Simple sample quiz and browser-local progress counter
- Health-check endpoint

## Important
This is a starter project, not a finished school management system. It does not yet include real student accounts, database storage, parent/teacher permissions, payments, live classes, or a full examination bank.

## Run locally
1. Install Node.js 20 or later.
2. Open a terminal in this project folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your private Groq API key in `.env` as `GROQ_API_KEY=...`.
6. Run `npm start`.
7. Open `http://localhost:3000`.

Never share your API key or put it in `public/app.js` or `public/index.html`.

## Deploy on Render
1. Upload this project to a GitHub repository.
2. Create a new Web Service on Render and connect the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. In Environment, add:
   - `GROQ_API_KEY` = your private Groq API key
   - `GROQ_MODEL` = `llama-3.3-70b-versatile`
6. Deploy. Check `https://YOUR-SERVICE.onrender.com/api/health`.
7. The result should show `status: "ok"` and `aiConfigured: true`.

If `aiConfigured` is false, the API key has not been added correctly to the service environment.
